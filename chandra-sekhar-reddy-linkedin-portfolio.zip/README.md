# Chandra Sekhar Reddy — Personal Portfolio

A responsive personal portfolio highlighting my professional experience in data analytics, business intelligence, reporting automation, and data engineering.

## View locally
Open `index.html` in a browser.

## Add my profile picture
Save my professional headshot as `profile.jpg` in the same folder as `index.html`. The website automatically displays it.

## Publish on Netlify
1. Open https://app.netlify.com/drop
2. Drag and drop this portfolio folder (with `index.html` inside it).
3. Use the generated public website URL for my LinkedIn Featured section and Contact info.

## Portfolio sections
Home, About, Selected Work, My Journey, Education, Impact & Recognition, Skills & Tools, Contact.

© Chandra Sekhar Reddy.
